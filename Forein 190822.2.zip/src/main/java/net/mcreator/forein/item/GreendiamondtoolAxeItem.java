
package net.mcreator.forein.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.item.AxeItem;

import net.mcreator.forein.itemgroup.ForeinItemGroup;
import net.mcreator.forein.ForeinModElements;

@ForeinModElements.ModElement.Tag
public class GreendiamondtoolAxeItem extends ForeinModElements.ModElement {
	@ObjectHolder("forein:greendiamondtool_axe")
	public static final Item block = null;

	public GreendiamondtoolAxeItem(ForeinModElements instance) {
		super(instance, 15);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new AxeItem(new IItemTier() {
			public int getMaxUses() {
				return 1741;
			}

			public float getEfficiency() {
				return 14f;
			}

			public float getAttackDamage() {
				return 34f;
			}

			public int getHarvestLevel() {
				return 8;
			}

			public int getEnchantability() {
				return 56;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(GreendiamondItem.block));
			}
		}, 1, -3f, new Item.Properties().group(ForeinItemGroup.tab)) {
		}.setRegistryName("greendiamondtool_axe"));
	}
}
