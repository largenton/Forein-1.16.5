// Made with Blockbench 4.3.1
// Exported for Minecraft version 1.15 - 1.16 with MCP mappings
// Paste this class into your mod and generate all required imports

public static class Modelruin_village extends EntityModel<Entity> {
	private final ModelRenderer ln;
	private final ModelRenderer pn;
	private final ModelRenderer body;
	private final ModelRenderer lr;
	private final ModelRenderer pt;
	private final ModelRenderer head;

	public Modelruin_village() {
		textureWidth = 64;
		textureHeight = 64;

		ln = new ModelRenderer(this);
		ln.setRotationPoint(2.0F, 15.0F, 0.0F);
		ln.setTextureOffset(32, 14).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 9.0F, 4.0F, 0.0F, false);

		pn = new ModelRenderer(this);
		pn.setRotationPoint(-2.0F, 15.0F, 0.0F);
		pn.setTextureOffset(0, 27).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 9.0F, 4.0F, 0.0F, false);

		body = new ModelRenderer(this);
		body.setRotationPoint(0.0F, 24.0F, 0.0F);
		body.setTextureOffset(0, 0).addBox(-4.0F, -19.0F, -2.0F, 8.0F, 10.0F, 4.0F, 0.0F, false);

		lr = new ModelRenderer(this);
		lr.setRotationPoint(6.0F, 5.0F, 0.0F);
		lr.setTextureOffset(24, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 10.0F, 4.0F, 0.0F, false);

		pt = new ModelRenderer(this);
		pt.setRotationPoint(-6.0F, 5.0F, 0.0F);
		pt.setTextureOffset(20, 23).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 10.0F, 4.0F, 0.0F, false);

		head = new ModelRenderer(this);
		head.setRotationPoint(0.0F, 5.0F, 0.0F);
		head.setTextureOffset(0, 14).addBox(-3.0F, -7.0F, -3.0F, 6.0F, 7.0F, 6.0F, 0.0F, false);
		head.setTextureOffset(18, 14).addBox(-1.0F, -3.0F, -5.0F, 2.0F, 3.0F, 2.0F, 0.0F, false);
	}

	@Override
	public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red,
			float green, float blue, float alpha) {
		ln.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		pn.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		body.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		lr.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		pt.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
		head.render(matrixStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity e) {
		this.head.rotateAngleY = f3 / (180F / (float) Math.PI);
		this.head.rotateAngleX = f4 / (180F / (float) Math.PI);
		this.ln.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
		this.pt.rotateAngleX = MathHelper.cos(f * 0.6662F + (float) Math.PI) * f1;
		this.lr.rotateAngleX = MathHelper.cos(f * 0.6662F) * f1;
		this.pn.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
	}
}