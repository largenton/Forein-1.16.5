
package net.mcreator.forein.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;

import net.mcreator.forein.itemgroup.ForeinItemGroup;
import net.mcreator.forein.ForeinModElements;

@ForeinModElements.ModElement.Tag
public class MinidestroyerItem extends ForeinModElements.ModElement {
	@ObjectHolder("forein:minidestroyer")
	public static final Item block = null;

	public MinidestroyerItem(ForeinModElements instance) {
		super(instance, 36);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new SwordItem(new IItemTier() {
			public int getMaxUses() {
				return 5000;
			}

			public float getEfficiency() {
				return 9.5f;
			}

			public float getAttackDamage() {
				return 11.5f;
			}

			public int getHarvestLevel() {
				return 5;
			}

			public int getEnchantability() {
				return 15;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(MoodevDustItem.block));
			}
		}, 3, -3.5f, new Item.Properties().group(ForeinItemGroup.tab)) {
		}.setRegistryName("minidestroyer"));
	}
}
