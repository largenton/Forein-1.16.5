
package net.mcreator.forein.fuel;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;

import net.mcreator.forein.item.MoodevDustItem;

@Mod.EventBusSubscriber
public class MoodiceFuel {
	@SubscribeEvent
	public static void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		if (event.getItemStack().getItem() == MoodevDustItem.block)
			event.setBurnTime(3600);
	}
}
