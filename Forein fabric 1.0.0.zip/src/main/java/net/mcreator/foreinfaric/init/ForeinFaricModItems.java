
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.foreinfaric.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.foreinfaric.item.MoodevToolsSwordItem;
import net.mcreator.foreinfaric.item.MoodevToolsShovelItem;
import net.mcreator.foreinfaric.item.MoodevToolsPickaxeItem;
import net.mcreator.foreinfaric.item.MoodevToolsHoeItem;
import net.mcreator.foreinfaric.item.MoodevToolsAxeItem;
import net.mcreator.foreinfaric.item.MoodevItem;
import net.mcreator.foreinfaric.item.MoodevArmorArmorItem;
import net.mcreator.foreinfaric.item.IcoItem;
import net.mcreator.foreinfaric.ForeinFaricMod;

public class ForeinFaricModItems {
	public static Item ICO;
	public static Item MOODEV;
	public static Item MOODEV_ORE;
	public static Item MOODEV_BLOCK;
	public static Item MOODEV_TOOLS_PICKAXE;
	public static Item MOODEV_TOOLS_AXE;
	public static Item MOODEV_TOOLS_SWORD;
	public static Item MOODEV_TOOLS_SHOVEL;
	public static Item MOODEV_TOOLS_HOE;
	public static Item MOODEV_ARMOR_ARMOR_HELMET;
	public static Item MOODEV_ARMOR_ARMOR_CHESTPLATE;
	public static Item MOODEV_ARMOR_ARMOR_LEGGINGS;
	public static Item MOODEV_ARMOR_ARMOR_BOOTS;

	public static void load() {
		ICO = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "ico"), new IcoItem());
		MOODEV = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev"), new MoodevItem());
		MOODEV_ORE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_ore"),
				new BlockItem(ForeinFaricModBlocks.MOODEV_ORE, new Item.Properties().tab(ForeinFaricModTabs.TAB_FOREIN_FABRIC)));
		MOODEV_BLOCK = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_block"),
				new BlockItem(ForeinFaricModBlocks.MOODEV_BLOCK, new Item.Properties().tab(ForeinFaricModTabs.TAB_FOREIN_FABRIC)));
		MOODEV_TOOLS_PICKAXE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_pickaxe"),
				new MoodevToolsPickaxeItem());
		MOODEV_TOOLS_AXE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_axe"), new MoodevToolsAxeItem());
		MOODEV_TOOLS_SWORD = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_sword"),
				new MoodevToolsSwordItem());
		MOODEV_TOOLS_SHOVEL = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_shovel"),
				new MoodevToolsShovelItem());
		MOODEV_TOOLS_HOE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_hoe"), new MoodevToolsHoeItem());
		MOODEV_ARMOR_ARMOR_HELMET = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_armor_armor_helmet"),
				new MoodevArmorArmorItem.Helmet());
		MOODEV_ARMOR_ARMOR_CHESTPLATE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_armor_armor_chestplate"),
				new MoodevArmorArmorItem.Chestplate());
		MOODEV_ARMOR_ARMOR_LEGGINGS = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_armor_armor_leggings"),
				new MoodevArmorArmorItem.Leggings());
		MOODEV_ARMOR_ARMOR_BOOTS = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_armor_armor_boots"),
				new MoodevArmorArmorItem.Boots());
	}
}
