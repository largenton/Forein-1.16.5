
package net.mcreator.foreinfaric.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.HoeItem;

import net.mcreator.foreinfaric.init.ForeinFaricModTabs;
import net.mcreator.foreinfaric.init.ForeinFaricModItems;

public class MoodevToolsHoeItem extends HoeItem {
	public MoodevToolsHoeItem() {
		super(new Tier() {
			public int getUses() {
				return 561;
			}

			public float getSpeed() {
				return 9.5f;
			}

			public float getAttackDamageBonus() {
				return -1f;
			}

			public int getLevel() {
				return 4;
			}

			public int getEnchantmentValue() {
				return 22;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(ForeinFaricModItems.MOODEV));
			}
		}, 0, -3.8f, new Item.Properties().tab(ForeinFaricModTabs.TAB_FOREIN_FABRIC));
	}
}
