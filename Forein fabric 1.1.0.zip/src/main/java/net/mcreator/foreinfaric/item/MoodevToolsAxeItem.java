
package net.mcreator.foreinfaric.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;

import net.mcreator.foreinfaric.init.ForeinFaricModTabs;
import net.mcreator.foreinfaric.init.ForeinFaricModItems;

public class MoodevToolsAxeItem extends AxeItem {
	public MoodevToolsAxeItem() {
		super(new Tier() {
			public int getUses() {
				return 1036;
			}

			public float getSpeed() {
				return 7f;
			}

			public float getAttackDamageBonus() {
				return 13.5f;
			}

			public int getLevel() {
				return 2;
			}

			public int getEnchantmentValue() {
				return 18;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(ForeinFaricModItems.MOODEV));
			}
		}, 1, -1.5f, new Item.Properties().tab(ForeinFaricModTabs.TAB_FOREIN_FABRIC));
	}
}
