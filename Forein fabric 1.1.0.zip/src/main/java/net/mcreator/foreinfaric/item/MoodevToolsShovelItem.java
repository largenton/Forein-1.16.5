
package net.mcreator.foreinfaric.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.foreinfaric.init.ForeinFaricModTabs;
import net.mcreator.foreinfaric.init.ForeinFaricModItems;

public class MoodevToolsShovelItem extends ShovelItem {
	public MoodevToolsShovelItem() {
		super(new Tier() {
			public int getUses() {
				return 1061;
			}

			public float getSpeed() {
				return 9.5f;
			}

			public float getAttackDamageBonus() {
				return 0.5f;
			}

			public int getLevel() {
				return 3;
			}

			public int getEnchantmentValue() {
				return 16;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(ForeinFaricModItems.MOODEV));
			}
		}, 1, -3.2000000000000001f, new Item.Properties().tab(ForeinFaricModTabs.TAB_FOREIN_FABRIC));
	}
}
