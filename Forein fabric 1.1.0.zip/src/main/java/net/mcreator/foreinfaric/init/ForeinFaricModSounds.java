
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.foreinfaric.init;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

public class ForeinFaricModSounds {
	public static SoundEvent UNDERTHEPIANO = new SoundEvent(new ResourceLocation("forein_faric", "underthepiano"));
	static {
		Registry.register(Registry.SOUND_EVENT, new ResourceLocation("forein_faric", "underthepiano"), UNDERTHEPIANO);
	}
}
