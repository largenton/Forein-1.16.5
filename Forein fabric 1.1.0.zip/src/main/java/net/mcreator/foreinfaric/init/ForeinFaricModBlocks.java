
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.foreinfaric.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.foreinfaric.block.MoodevOreBlock;
import net.mcreator.foreinfaric.block.MoodevBlockBlock;
import net.mcreator.foreinfaric.ForeinFaricMod;

public class ForeinFaricModBlocks {
	public static Block MOODEV_ORE;
	public static Block MOODEV_BLOCK;

	public static void load() {
		MOODEV_ORE = Registry.register(Registry.BLOCK, new ResourceLocation(ForeinFaricMod.MODID, "moodev_ore"), new MoodevOreBlock());
		MOODEV_BLOCK = Registry.register(Registry.BLOCK, new ResourceLocation(ForeinFaricMod.MODID, "moodev_block"), new MoodevBlockBlock());
	}

	public static void clientLoad() {
		MoodevOreBlock.clientInit();
		MoodevBlockBlock.clientInit();
	}
}
