
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.foreinfaric.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.foreinfaric.item.WoodToolsPlusSwordItem;
import net.mcreator.foreinfaric.item.WoodToolsPlusShovelItem;
import net.mcreator.foreinfaric.item.WoodToolsPlusPickaxeItem;
import net.mcreator.foreinfaric.item.WoodToolsPlusHoeItem;
import net.mcreator.foreinfaric.item.WoodToolsPlusAxeItem;
import net.mcreator.foreinfaric.item.TreearmorArmorItem;
import net.mcreator.foreinfaric.item.MoodevToolsSwordItem;
import net.mcreator.foreinfaric.item.MoodevToolsShovelItem;
import net.mcreator.foreinfaric.item.MoodevToolsPlusSwordItem;
import net.mcreator.foreinfaric.item.MoodevToolsPlusShovelItem;
import net.mcreator.foreinfaric.item.MoodevToolsPlusPickaxeItem;
import net.mcreator.foreinfaric.item.MoodevToolsPlusHoeItem;
import net.mcreator.foreinfaric.item.MoodevToolsPlusAxeItem;
import net.mcreator.foreinfaric.item.MoodevToolsPickaxeItem;
import net.mcreator.foreinfaric.item.MoodevToolsHoeItem;
import net.mcreator.foreinfaric.item.MoodevToolsAxeItem;
import net.mcreator.foreinfaric.item.MoodevItem;
import net.mcreator.foreinfaric.item.MoodevArmorArmorItem;
import net.mcreator.foreinfaric.item.IcoItem;
import net.mcreator.foreinfaric.ForeinFaricMod;

public class ForeinFaricModItems {
	public static Item ICO;
	public static Item MOODEV_ORE;
	public static Item MOODEV_BLOCK;
	public static Item MOODEV_TOOLS_PICKAXE;
	public static Item MOODEV_TOOLS_AXE;
	public static Item MOODEV_TOOLS_SWORD;
	public static Item MOODEV_TOOLS_SHOVEL;
	public static Item MOODEV_TOOLS_HOE;
	public static Item MOODEV_ARMOR_ARMOR_HELMET;
	public static Item MOODEV_ARMOR_ARMOR_CHESTPLATE;
	public static Item MOODEV_ARMOR_ARMOR_LEGGINGS;
	public static Item MOODEV_ARMOR_ARMOR_BOOTS;
	public static Item MOODEV_TOOLS_PLUS_PICKAXE;
	public static Item MOODEV_TOOLS_PLUS_AXE;
	public static Item MOODEV_TOOLS_PLUS_SWORD;
	public static Item MOODEV_TOOLS_PLUS_SHOVEL;
	public static Item MOODEV_TOOLS_PLUS_HOE;
	public static Item TREEARMOR_ARMOR_HELMET;
	public static Item TREEARMOR_ARMOR_CHESTPLATE;
	public static Item TREEARMOR_ARMOR_LEGGINGS;
	public static Item TREEARMOR_ARMOR_BOOTS;
	public static Item WOOD_TOOLS_PLUS_PICKAXE;
	public static Item WOOD_TOOLS_PLUS_AXE;
	public static Item WOOD_TOOLS_PLUS_SWORD;
	public static Item WOOD_TOOLS_PLUS_SHOVEL;
	public static Item WOOD_TOOLS_PLUS_HOE;
	public static Item MOODEV;

	public static void load() {
		ICO = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "ico"), new IcoItem());
		MOODEV_ORE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_ore"),
				new BlockItem(ForeinFaricModBlocks.MOODEV_ORE, new Item.Properties().tab(ForeinFaricModTabs.TAB_FOREIN_FABRIC)));
		MOODEV_BLOCK = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_block"),
				new BlockItem(ForeinFaricModBlocks.MOODEV_BLOCK, new Item.Properties().tab(ForeinFaricModTabs.TAB_FOREIN_FABRIC)));
		MOODEV_TOOLS_PICKAXE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_pickaxe"),
				new MoodevToolsPickaxeItem());
		MOODEV_TOOLS_AXE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_axe"), new MoodevToolsAxeItem());
		MOODEV_TOOLS_SWORD = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_sword"),
				new MoodevToolsSwordItem());
		MOODEV_TOOLS_SHOVEL = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_shovel"),
				new MoodevToolsShovelItem());
		MOODEV_TOOLS_HOE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_hoe"), new MoodevToolsHoeItem());
		MOODEV_ARMOR_ARMOR_HELMET = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_armor_armor_helmet"),
				new MoodevArmorArmorItem.Helmet());
		MOODEV_ARMOR_ARMOR_CHESTPLATE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_armor_armor_chestplate"),
				new MoodevArmorArmorItem.Chestplate());
		MOODEV_ARMOR_ARMOR_LEGGINGS = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_armor_armor_leggings"),
				new MoodevArmorArmorItem.Leggings());
		MOODEV_ARMOR_ARMOR_BOOTS = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_armor_armor_boots"),
				new MoodevArmorArmorItem.Boots());
		MOODEV_TOOLS_PLUS_PICKAXE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_plus_pickaxe"),
				new MoodevToolsPlusPickaxeItem());
		MOODEV_TOOLS_PLUS_AXE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_plus_axe"),
				new MoodevToolsPlusAxeItem());
		MOODEV_TOOLS_PLUS_SWORD = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_plus_sword"),
				new MoodevToolsPlusSwordItem());
		MOODEV_TOOLS_PLUS_SHOVEL = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_plus_shovel"),
				new MoodevToolsPlusShovelItem());
		MOODEV_TOOLS_PLUS_HOE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev_tools_plus_hoe"),
				new MoodevToolsPlusHoeItem());
		TREEARMOR_ARMOR_HELMET = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "treearmor_armor_helmet"),
				new TreearmorArmorItem.Helmet());
		TREEARMOR_ARMOR_CHESTPLATE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "treearmor_armor_chestplate"),
				new TreearmorArmorItem.Chestplate());
		TREEARMOR_ARMOR_LEGGINGS = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "treearmor_armor_leggings"),
				new TreearmorArmorItem.Leggings());
		TREEARMOR_ARMOR_BOOTS = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "treearmor_armor_boots"),
				new TreearmorArmorItem.Boots());
		WOOD_TOOLS_PLUS_PICKAXE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "wood_tools_plus_pickaxe"),
				new WoodToolsPlusPickaxeItem());
		WOOD_TOOLS_PLUS_AXE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "wood_tools_plus_axe"),
				new WoodToolsPlusAxeItem());
		WOOD_TOOLS_PLUS_SWORD = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "wood_tools_plus_sword"),
				new WoodToolsPlusSwordItem());
		WOOD_TOOLS_PLUS_SHOVEL = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "wood_tools_plus_shovel"),
				new WoodToolsPlusShovelItem());
		WOOD_TOOLS_PLUS_HOE = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "wood_tools_plus_hoe"),
				new WoodToolsPlusHoeItem());
		MOODEV = Registry.register(Registry.ITEM, new ResourceLocation(ForeinFaricMod.MODID, "moodev"), new MoodevItem());
	}
}
