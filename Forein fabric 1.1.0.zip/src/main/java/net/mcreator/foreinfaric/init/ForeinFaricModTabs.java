
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.foreinfaric.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;

public class ForeinFaricModTabs {
	public static CreativeModeTab TAB_FOREIN_FABRIC;

	public static void load() {
		TAB_FOREIN_FABRIC = FabricItemGroupBuilder.create(new ResourceLocation("forein_faric", "forein_fabric"))
				.icon(() -> new ItemStack(ForeinFaricModItems.ICO)).build();
	}
}
